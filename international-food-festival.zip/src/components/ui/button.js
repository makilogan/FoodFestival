export function Button({ children, className, onClick }) {
  return (
    <button className={`rounded-xl border px-4 py-2 ${className}`} onClick={onClick}>
      {children}
    </button>
  );
}
