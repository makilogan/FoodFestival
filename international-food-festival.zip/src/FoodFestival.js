
import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

const countries = [
  'Japan', 'India', 'Africa', 'Italy', 'Germany',
  'South Korea', 'Singapore', 'Philippines', 'Caribbean', 'Vietnam'
];

const countryFlags = {
  Japan: '🇯🇵', India: '🇮🇳', Africa: '🌍', Italy: '🇮🇹', Germany: '🇩🇪',
  'South Korea': '🇰🇷', Singapore: '🇸🇬', Philippines: '🇵🇭', Caribbean: '🌴', Vietnam: '🇻🇳'
};

const countryContent = {
  Japan: {
    dishes: ['Sushi', 'Ramen', 'Tempura'],
    images: ['/images/japan1.jpg', '/images/japan2.jpg']
  },
  India: {
    dishes: ['Biryani', 'Butter Chicken', 'Samosa'],
    images: ['/images/india1.jpg', '/images/india2.jpg']
  },
  Africa: {
    dishes: ['Jollof Rice', 'Suya', 'Injera'],
    images: ['/images/africa1.jpg', '/images/africa2.jpg']
  },
  Italy: {
    dishes: ['Pizza', 'Pasta', 'Gelato'],
    images: ['/images/italy1.jpg', '/images/italy2.jpg']
  },
  Germany: {
    dishes: ['Bratwurst', 'Pretzels', 'Schnitzel'],
    images: ['/images/germany1.jpg', '/images/germany2.jpg']
  },
  'South Korea': {
    dishes: ['Kimchi', 'Bibimbap', 'Tteokbokki'],
    images: ['/images/korea1.jpg', '/images/korea2.jpg']
  },
  Singapore: {
    dishes: ['Chilli Crab', 'Hainanese Chicken Rice', 'Laksa'],
    images: ['/images/singapore1.jpg', '/images/singapore2.jpg']
  },
  Philippines: {
    dishes: ['Adobo', 'Sinigang', 'Lechon'],
    images: ['/images/philippines1.jpg', '/images/philippines2.jpg']
  },
  Caribbean: {
    dishes: ['Jerk Chicken', 'Curry Goat', 'Fried Plantains'],
    images: ['/images/caribbean1.jpg', '/images/caribbean2.jpg']
  },
  Vietnam: {
    dishes: ['Pho', 'Banh Mi', 'Spring Rolls'],
    images: ['/images/vietnam1.jpg', '/images/vietnam2.jpg']
  }
};

export default function FoodFestival() {
  const [selectedCountry, setSelectedCountry] = useState(null);

  const handleCountryClick = (country) => {
    setSelectedCountry(country);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 to-pink-200 p-6 text-center">
      <motion.h1
        className="text-4xl font-bold mb-6 text-rose-700"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        🌎 International Food Festival 🍱
      </motion.h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mb-10">
        {countries.map((country) => (
          <motion.div
            key={country}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              className="w-full text-lg p-4 bg-white shadow-md hover:bg-rose-100"
              onClick={() => handleCountryClick(country)}
            >
              {countryFlags[country]} {country}
            </Button>
          </motion.div>
        ))}
      </div>

      {selectedCountry && (
        <motion.div
          className="mx-auto max-w-xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-white p-6 rounded-2xl shadow-xl">
            <CardContent>
              <h2 className="text-2xl font-bold mb-4 text-rose-600">
                {countryFlags[selectedCountry]} {selectedCountry} Menu
              </h2>
              <div className="text-left">
                <h3 className="text-lg font-semibold mb-2">Popular Dishes:</h3>
                <ul className="list-disc pl-5 text-gray-700 mb-4">
                  {countryContent[selectedCountry]?.dishes.map((dish, index) => (
                    <li key={index}>{dish}</li>
                  ))}
                </ul>
                <h3 className="text-lg font-semibold mb-2">Gallery:</h3>
                <div className="grid grid-cols-2 gap-4">
                  {countryContent[selectedCountry]?.images.map((img, index) => (
                    <img key={index} src={img} alt={`${selectedCountry} food`} className="rounded-lg shadow" />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
