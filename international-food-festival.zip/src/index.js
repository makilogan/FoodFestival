import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import FoodFestival from './FoodFestival';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <FoodFestival />
  </React.StrictMode>
);
